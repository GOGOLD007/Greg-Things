package com.creativemd.creativecore.client.mods.optifine;

public interface OptifineHelper {
    static boolean isActive() {
        return false;
    }
}
