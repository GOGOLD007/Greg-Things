package com.creativemd.littletiles.client.render.tile;

public class LittleRenderBox {
    public boolean needsResorting;
}
