package com.creativemd.littletiles.client.render.cache;

public class LayeredRenderBoxCache {
}
