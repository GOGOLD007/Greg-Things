package gregtech.api.pipenet.block.simple;

@SuppressWarnings("ALL")
public class EmptyNodeData {

    public static final EmptyNodeData INSTANCE = new EmptyNodeData();

    private EmptyNodeData() {
    }
}
