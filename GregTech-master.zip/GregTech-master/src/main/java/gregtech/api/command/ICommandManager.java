package gregtech.api.command;

import net.minecraft.command.ICommand;

public interface ICommandManager {

    void addCommand(ICommand command);
}
