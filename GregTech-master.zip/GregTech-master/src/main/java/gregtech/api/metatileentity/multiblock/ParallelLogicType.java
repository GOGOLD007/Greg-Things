package gregtech.api.metatileentity.multiblock;

public enum ParallelLogicType {
    MULTIPLY, APPEND_ITEMS
}
