package gregtech.api.metatileentity.multiblock;

public interface IPrimitivePump {

    /**
     *
     * @return the amount of fluid to produce
     */
    int getFluidProduction();
}
