package gregtech.api.gui.ingredient;

public interface IIngredientSlot {

    Object getIngredientOverMouse(int mouseX, int mouseY);

}
