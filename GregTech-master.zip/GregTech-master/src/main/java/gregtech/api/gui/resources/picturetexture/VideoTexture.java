package gregtech.api.gui.resources.picturetexture;

public class VideoTexture extends PictureTexture {
    //TODO implementations of it in the future

    public VideoTexture(String url) {
        super(100, 100);
    }
    
    @Override
    public void tick() {
    
    }
    
    @Override
    public int getTextureID() {
        return 0;
    }
}
