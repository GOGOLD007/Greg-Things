package gregtech.api.gui;

public interface IRenderContext {

}
