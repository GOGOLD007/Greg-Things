package gregtech.api.cover;

import net.minecraft.block.state.IBlockState;

public interface IFacadeCover {

    IBlockState getVisualState();
}
