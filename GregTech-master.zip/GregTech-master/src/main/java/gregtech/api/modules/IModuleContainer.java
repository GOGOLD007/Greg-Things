package gregtech.api.modules;

public interface IModuleContainer {

    String getID();
}
