package gregtech.api.modules;

import net.minecraftforge.fml.common.eventhandler.Event;

public class ModuleContainerRegistryEvent extends Event {
}
