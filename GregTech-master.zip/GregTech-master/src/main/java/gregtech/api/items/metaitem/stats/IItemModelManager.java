package gregtech.api.items.metaitem.stats;

public interface IItemModelManager extends IItemComponent {
}
