package gregtech.api.items.metaitem.stats;

/**
 * Describes generic component attachable to metaitem
 * Multiple components can be attached to one item
 */
public interface IItemComponent {
}
