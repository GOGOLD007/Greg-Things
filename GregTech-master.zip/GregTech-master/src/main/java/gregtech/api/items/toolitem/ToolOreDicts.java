package gregtech.api.items.toolitem;

public enum ToolOreDicts {

    craftingToolSaw,
    craftingToolHammer,
    craftingToolMallet,
    craftingToolWrench,
    craftingToolFile,
    craftingToolCrowbar,
    craftingToolScrewdriver,
    craftingToolWireCutter,
    craftingToolKnife,
    craftingToolButcheryKnife,
    craftingToolMortar,
    craftingToolDrill,
}
